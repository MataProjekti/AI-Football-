import { Component, useEffect, useMemo, useState } from 'react'
import './App.css'

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001'
// redosled lige: manji broj = važnija liga
const RANK = { 39: 1, 140: 2, 135: 3, 78: 4, 61: 5, 2: 6, 3: 7, 848: 8, 88: 9, 94: 10, 40: 11, 286: 12 }
const LIVE = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'LIVE', 'INT']
const FIN = ['FT', 'AET', 'PEN']
const group = (s) => (LIVE.includes(s) ? 'live' : FIN.includes(s) ? 'fin' : s === 'NS' || s === 'TBD' ? 'up' : 'other')
const today = () => new Date().toLocaleDateString('sv-SE')
const shift = (d, n) => { const x = new Date(d + 'T12:00'); x.setDate(x.getDate() + n); return x.toLocaleDateString('sv-SE') }
const hhmm = (d) => new Date(d).toLocaleTimeString('sr-Latn-RS', { hour: '2-digit', minute: '2-digit' })
const getJSON = async (p) => { const r = await fetch(API + p); const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Greška'); return j }

class Boundary extends Component {
  state = { e: null }
  static getDerivedStateFromError(e) { return { e } }
  render() { return this.state.e ? <div className="empty err">Greška u prikazu: {String(this.state.e.message || this.state.e)}</div> : this.props.children }
}

function Form({ list }) {
  if (!list?.length) return <span className="mut">Nema podataka</span>
  return (
    <span className="form">
      {list.map((f, i) => (
        <span key={i} className={'dot ' + f.res} title={`${f.date} ${f.home ? 'protiv' : 'kod'} ${f.opp} ${f.score}`}>
          {f.res === 'W' ? 'P' : f.res === 'D' ? 'N' : 'I'}
        </span>
      ))}
    </span>
  )
}

const MK = { goal: '⚽', og: '⚽', yellow: '🟨', red: '🟥', out: '🔻', in: '🔺' }
const marks = (p) => (p.marks || []).map((k) => MK[k]).join('')
const evIcon = (e) => (e.type === 'Goal' ? '⚽' : e.type === 'Card' ? (e.detail?.includes('Red') ? '🟥' : '🟨') : '🔄')

function Pitch({ home, away }) {
  const lines = (pl) => ['G', 'D', 'M', 'F'].map((p) => pl.filter((x) => x.pos === p)).filter((l) => l.length)
  const side = (lu, isHome) =>
    lu ? lines(lu.players).map((l, li, all) => {
      const x = ((li + 0.5) / all.length) * 44 + 3
      return l.map((p, k) => (
        <div key={p.name + k} className={'pl ' + (isHome ? 'h' : 'a')} style={{ left: (isHome ? x : 100 - x) + '%', top: ((k + 0.5) / l.length) * 100 + '%' }}>
          <em />{p.name.split(' ').slice(-1)[0]}<span className="mk">{marks(p)}</span>
        </div>
      ))
    }) : null
  return <div className="pitch">{side(home, true)}{side(away, false)}</div>
}

function Bench({ home, away, m }) {
  const col = (lu, name) => (
    <div>
      <div className="bn">{name}</div>
      {lu?.subs?.length ? lu.subs.map((p, i) => <div className="bp" key={i}><span>{p.no}</span>{p.name}<span className="mk">{marks(p)}</span></div>) : <div className="note">Nema podataka</div>}
    </div>
  )
  return <div className="bench">{col(home, m.home.name)}{col(away, m.away.name)}</div>
}

function Timeline({ events }) {
  const hx = (e) => (e.t <= 45 ? 1 : e.t <= 90 ? 2 : 3)
  const names = { 1: '1. poluvreme', 2: '2. poluvreme', 3: 'Produžeci' }
  let sh = 0, sa = 0
  const groups = [1, 2, 3].map((h) => {
    const evs = events.filter((e) => hx(e) === h)
    evs.forEach((e) => { if (e.type === 'Goal' && e.detail !== 'Missed Penalty') ((e.side === 'home') !== (e.detail === 'Own Goal') ? sh++ : sa++) })
    return { h, evs, sc: `${sh} - ${sa}` }
  }).filter((g) => g.evs.length)
  if (!groups.length) return <div className="note">Još nema događaja.</div>
  return groups.map((g) => (
    <div key={g.h}>
      <div className="gh"><span>{names[g.h]}</span><b>{g.sc}</b></div>
      {g.evs.map((e, i) => (
        <div className={'er ' + (e.side === 'home' ? 'h' : 'a')} key={i}>
          <b>{e.min}'</b><i>{evIcon(e)}</i>
          <span>
            <strong>{e.type === 'subst' ? e.assist : e.player}</strong>{' '}
            <small>{e.type === 'subst' ? e.player : e.type === 'Goal' ? (e.detail === 'Own Goal' ? '(autogol)' : e.detail === 'Penalty' ? '(penal)' : e.assist ? `(${e.assist})` : '') : e.comment ? `(${e.comment})` : ''}</small>
          </span>
        </div>
      ))}
    </div>
  ))
}

function Detail({ m }) {
  const mode = group(m.status)
  const pre = mode === 'up' || mode === 'other'
  const [d, setD] = useState(null)
  const [err, setErr] = useState('')
  const [at, setAt] = useState(Date.now())
  const [now, setNow] = useState(Date.now())

  useEffect(() => {
    setD(null); setErr('')
    let alive = true
    const load = () => getJSON(`/api/match/${m.id}${pre ? '' : '/live'}`).then((x) => { if (alive) { setD(x); setAt(Date.now()) } }).catch((e) => alive && setErr(e.message))
    load()
    const t = mode === 'live' ? setInterval(load, 5000) : null
    const k = mode === 'live' ? setInterval(() => setNow(Date.now()), 5000) : null
    return () => { alive = false; clearInterval(t); clearInterval(k) }
  }, [m.id])

  if (err) return <div className="empty err">{err}</div>
  if (!d) return <div className="empty">Učitavam podatke…</div>
  const f = d.fixture || m
  const g = group(f.status)
  const actual = d.lineupStatus === 'actual'
  const lu = d.lineups
  const pr = d.prediction
  const minute = f.status === 'HT' ? 'Poluvreme' : f.status === 'BT' ? 'Pauza' : `${(f.min || 0) + (['1H', '2H'].includes(f.status) ? Math.floor((now - at) / 60000) : 0)}'`

  return (
    <>
      <div className="hd">
        <div className="tmx"><img src={m.home.logo} alt="" /><b>{m.home.name}</b></div>
        <div className="mid">
          {pre ? <span className="tm">{hhmm(m.date)}</span> : <><div className="big">{f.goals.home ?? 0}<i>:</i>{f.goals.away ?? 0}</div><div className={g === 'live' ? 'live' : 'cap'}>{g === 'live' ? `● ${minute}` : 'Završeno'}</div></>}
        </div>
        <div className="tmx"><img src={m.away.logo} alt="" /><b>{m.away.name}</b></div>
      </div>
      <div className="cap">{m.league.name} · {m.league.country}</div>

      {!pre && (
        <>
          <div className="sec">Tok utakmice</div>
          <Timeline events={d.events} />
          <div className="sec">Statistika</div>
          {d.stats.length ? d.stats.map((r) => (
            <div className="st" key={r.label}>
              <div className="sv"><b>{r.home}</b><span>{r.label}</span><b>{r.away}</b></div>
              <div className="sb"><i style={{ width: (r.h / (r.h + r.a || 1)) * 100 + '%' }} /></div>
            </div>
          )) : <div className="note">Statistika još nije dostupna.</div>}
        </>
      )}

      {pre && (
        <>
          <div className="sec">Predviđeni rezultat</div>
          {pr ? (
            <>
              <div className="big"><span>{pr.score.home}</span><i>:</i><span>{pr.score.away}</span></div>
              <div className="cap">Očekivani golovi: {pr.xg[0]} – {pr.xg[1]}</div>
              <div className="bar"><span style={{ width: pr.probs.home + '%' }} /><span style={{ width: pr.probs.draw + '%' }} /><span style={{ width: pr.probs.away + '%' }} /></div>
              <div className="pc"><span>{m.home.name} {pr.probs.home}%</span><span>X {pr.probs.draw}%</span><span>{m.away.name} {pr.probs.away}%</span></div>
              {pr.basis === 'api' && <div className="note">Procena je gruba: forma timova još nije dostupna, pa se oslanja na predikciju API-ja.</div>}
              <div className="sec">Predviđeni strelci</div>
              <div className="sc2">{pr.scorers.length ? pr.scorers.map((s, i) => <span key={i} title={`${s.goals} gol(ova) u poslednja 2 meča`}>{s.name} <b>{s.chance}%</b></span>) : <span>Nema podataka o sastavu</span>}</div>
            </>
          ) : <div className="empty">Nema dovoljno podataka za predikciju.</div>}
        </>
      )}

      <div className="sec">{actual ? 'Stvarni sastavi' : 'Predviđeni sastavi'}{lu?.home?.formation && ` · ${lu.home.formation} / ${lu.away?.formation || '?'}`}</div>
      {lu?.home || lu?.away ? <><Pitch home={lu.home} away={lu.away} /><div className="sec">Rezerve</div><Bench home={lu.home} away={lu.away} m={m} /></> : <div className="empty">{pre ? 'Sastavi još nisu dostupni.' : 'Sastavi nisu objavljeni.'}</div>}
      {!actual && d.lineupSource && lu?.home && <div className="note">Predviđeni sastav je iz poslednjeg dostupnog meča ({d.lineupSource}), bez povređenih igrača.</div>}

      {pre && (
        <>
          <div className="sec">Forma (poslednjih 5)</div>
          <div className="row"><span>{m.home.name}</span><Form list={d.form.home} /></div>
          <div className="row"><span>{m.away.name}</span><Form list={d.form.away} /></div>
          <div className="note">P pobeda · N nerešeno · I izgubljeno</div>
          {d.warnings?.length > 0 && <div className="note err">{d.warnings[0]}</div>}
          <div className="sec">Međusobni mečevi</div>
          {d.h2h.length ? d.h2h.map((h, i) => <div className="row" key={i}><span>{h.date}</span><span>{h.home} {h.score} {h.away}</span></div>) : <div className="note">Nema odigranih mečeva.</div>}
          <div className="sec">Povrede i suspenzije</div>
          {d.injuries.length ? d.injuries.map((x, i) => (
            <div className="row" key={i}><span>{x.player} <small>({x.team})</small></span><span>{x.reason}{x.type === 'Questionable' ? ' (sumnjiv)' : ''} · {x.back ? `vraća se ${x.back}` : 'povratak nepoznat'}</span></div>
          )) : <div className="note">Nema prijavljenih povreda.</div>}
        </>
      )}
    </>
  )
}

export default function App() {
  const [date, setDate] = useState(today())
  const [all, setAll] = useState([])
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')
  const [country, setCountry] = useState('')
  const [league, setLeague] = useState('')
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('all')
  const [topOnly, setTopOnly] = useState(true)
  const [sort, setSort] = useState('rank')
  const [sel, setSel] = useState(null)

  const load = () => {
    setLoading(true); setErr('')
    getJSON(`/api/fixtures?date=${date}`).then(setAll).catch((e) => setErr(e.message)).finally(() => setLoading(false))
  }
  useEffect(load, [date])
  useEffect(() => {
    if (date !== today()) return
    const t = setInterval(load, 300000)
    return () => clearInterval(t)
  }, [date])

  const countries = useMemo(() => [...new Set(all.map((m) => m.league.country))].sort(), [all])
  const leagues = useMemo(() => {
    const map = new Map()
    all.filter((m) => !country || m.league.country === country).forEach((m) => map.set(m.league.id, m.league.name))
    return [...map].sort((a, b) => (RANK[a[0]] || 99) - (RANK[b[0]] || 99))
  }, [all, country])

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase()
    const narrow = country || league || needle
    return all.filter((m) =>
      (!country || m.league.country === country) &&
      (!league || String(m.league.id) === league) &&
      (!needle || (m.home.name + m.away.name).toLowerCase().includes(needle)) &&
      (status === 'all' || group(m.status) === status) &&
      (narrow || !topOnly || RANK[m.league.id]))
  }, [all, country, league, q, status, topOnly])

  const groups = useMemo(() => {
    const g = new Map()
    shown.forEach((m) => { if (!g.has(m.league.id)) g.set(m.league.id, { league: m.league, ms: [] }); g.get(m.league.id).ms.push(m) })
    const arr = [...g.values()]
    arr.forEach((x) => x.ms.sort((a, b) => new Date(a.date) - new Date(b.date)))
    return sort === 'rank' ? arr.sort((a, b) => (RANK[a.league.id] || 99) - (RANK[b.league.id] || 99) || a.league.name.localeCompare(b.league.name)) : arr
  }, [shown, sort])

  const selected = all.find((m) => m.id === sel)

  return (
    <>
      <header><div className="logo">Gol<span>Oko</span></div><span className="demo">{all.length} utakmica za izabrani datum</span></header>
      <div className="wrap">
        <aside className="side">
          <div>
            <span className="lab">Datum</span>
            <div className="dates">
              <button onClick={() => setDate(shift(date, -1))} aria-label="Prethodni dan">‹</button>
              <input type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
              <button onClick={() => setDate(shift(date, 1))} aria-label="Sledeći dan">›</button>
            </div>
            <button className="full" onClick={() => setDate(today())}>Danas</button>
          </div>
          <div><span className="lab">Država</span>
            <select value={country} onChange={(e) => { setCountry(e.target.value); setLeague('') }}>
              <option value="">Sve države</option>{countries.map((c) => <option key={c}>{c}</option>)}
            </select></div>
          <div><span className="lab">Liga</span>
            <select value={league} onChange={(e) => setLeague(e.target.value)}>
              <option value="">Sve lige</option>{leagues.map(([id, n]) => <option key={id} value={id}>{n}</option>)}
            </select></div>
          <div><span className="lab">Tim</span><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Npr. Arsenal" /></div>
          <div><span className="lab">Status</span>
            <div className="seg">{[['all', 'Sve'], ['live', 'Uživo'], ['up', 'Predstoje'], ['fin', 'Završene']].map(([v, t]) => <button key={v} className={status === v ? 'on' : ''} onClick={() => setStatus(v)}>{t}</button>)}</div></div>
          <div><span className="lab">Sortiranje</span>
            <div className="seg">{[['rank', 'Najbolje prvo'], ['time', 'Liga A-Š']].map(([v, t]) => <button key={v} className={sort === v ? 'on' : ''} onClick={() => setSort(v)}>{t}</button>)}</div></div>
          <label className="chk"><input type="checkbox" checked={topOnly} onChange={(e) => setTopOnly(e.target.checked)} /> Samo najjače lige (kad nema filtera)</label>
        </aside>

        <section className="main">
          <h2>{new Date(date + 'T12:00').toLocaleDateString('sr-Latn-RS', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</h2>
          <p className="sub">{loading ? 'Učitavam…' : `${shown.length} utakmica`}</p>
          {err && <div className="empty err">{err}</div>}
          {!loading && !err && !groups.length && <div className="empty">Nema utakmica za ove filtere. Isključi „Samo najjače lige" ili promeni datum.</div>}
          {groups.map(({ league: l, ms }) => (
            <div className="league" key={l.id}>
              <div className="lh"><h3><img src={l.logo} alt="" /> {l.name}</h3><small>{l.country}</small></div>
              {ms.map((m) => {
                const g = group(m.status)
                return (
                  <button key={m.id} className={'m' + (sel === m.id ? ' sel' : '')} onClick={() => setSel(m.id)}>
                    <span className="tm">{g === 'live' ? <span className="live">● {m.min}'</span> : g === 'fin' ? 'Kraj' : hhmm(m.date)}</span>
                    <span className="t"><img src={m.home.logo} alt="" />{m.home.name}</span>
                    <span className="sc">{g === 'up' || g === 'other' ? '–' : `${m.goals.home ?? 0} : ${m.goals.away ?? 0}`}</span>
                    <span className="t r">{m.away.name}<img src={m.away.logo} alt="" /></span>
                  </button>
                )
              })}
            </div>
          ))}
        </section>

        <aside className="panel">
          {selected ? <Boundary key={selected.id}><Detail m={selected} /></Boundary> : <div className="empty">Klikni na utakmicu da vidiš AI analizu, sastave i formu.</div>}
        </aside>
      </div>
    </>
  )
}