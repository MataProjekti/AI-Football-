import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import fs from 'fs'

const app = express()
app.use(cors())

const FB = 'https://v3.football.api-sports.io'
const FIN = ['FT', 'AET', 'PEN']
const LIVE_TTL = Number(process.env.LIVE_TTL_MS || 15000)
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const cache = new Map()

const memo = (key, ttl, fn) => {
  const c = cache.get(key)
  if (c && Date.now() - c.t < ttl) return c.v
  const v = fn()
  cache.set(key, { t: Date.now(), v })
  v.catch(() => cache.delete(key))
  return v
}

// Do FB_PER_MIN poziva odjednom (burst), pa čeka. Besplatan plan: 10/min.
const PER_MIN = Number(process.env.FB_PER_MIN || 9)
const stamps = []
let chain = Promise.resolve()
let pending = 0
const throttle = (fn) => {
  pending++
  const slot = chain.then(async () => {
    for (;;) {
      const now = Date.now()
      while (stamps.length && now - stamps[0] > 60000) stamps.shift()
      if (stamps.length < PER_MIN) break
      await sleep(60000 - (now - stamps[0]) + 50)
    }
    stamps.push(Date.now())
  })
  chain = slot.catch(() => {})
  return slot.then(fn).finally(() => pending--)
}

const used = () => { const n = Date.now(); return stamps.filter((x) => n - x < 60000).length }
const call = async (path) => {
  const r = await throttle(() => fetch(FB + path, { headers: { 'x-apisports-key': process.env.FOOTBALL_API_KEY } }))
  const j = await r.json()
  if (j.errors && !Array.isArray(j.errors) && Object.keys(j.errors).length) throw new Error(Object.values(j.errors).join(' '))
  return j.response
}
const fb = (path, ttl = 300000) => memo('fb' + path, ttl, () => call(path))
const safe = (p) => (p ? Promise.race([p.catch(() => null), sleep(25000).then(() => null)]) : null)
const pick = (arr, team) => arr?.find((x) => x.team.id === team)
const key = (n) => String(n).toLowerCase().split(' ').pop()
const num = (v) => { const n = parseFloat(v); return Number.isNaN(n) ? null : n }
const desc = (x, y) => new Date(y.fixture.date) - new Date(x.fixture.date)

const slim = (f) => ({
  id: f.fixture.id, date: f.fixture.date, status: f.fixture.status.short, min: f.fixture.status.elapsed,
  league: { id: f.league.id, name: f.league.name, country: f.league.country, logo: f.league.logo, season: f.league.season },
  home: { id: f.teams.home.id, name: f.teams.home.name, logo: f.teams.home.logo },
  away: { id: f.teams.away.id, name: f.teams.away.name, logo: f.teams.away.logo },
  goals: f.goals,
})
const mapP = (p) => ({ name: p.player.name, pos: p.player.pos, no: p.player.number })
const normLU = (l) => (l ? { formation: l.formation, coach: l.coach?.name, players: l.startXI.map(mapP), subs: (l.substitutes || []).map(mapP) } : null)

// ---------- istorija mečeva (za formu), gradi se u pozadini i čuva u history.json ----------
const HF = new URL('./history.json', import.meta.url)
let hist = {}
try { hist = JSON.parse(fs.readFileSync(HF, 'utf8')) } catch {}
let histErr = null
async function buildHistory() {
  for (let i = 1; i <= 35; i++) {
    const date = new Date(Date.now() - i * 864e5).toLocaleDateString('sv-SE')
    if (hist[date]) continue
    while (pending > 0 || used() >= PER_MIN - 5) await sleep(3000) // istorija ne sme da gladuje korisnikove pozive
    try {
      const list = await call(`/fixtures?date=${date}&timezone=Europe/Belgrade`)
      hist[date] = list.filter((f) => FIN.includes(f.fixture.status.short)).map((f) => ({ id: f.fixture.id, h: f.teams.home.id, a: f.teams.away.id, hn: f.teams.home.name, an: f.teams.away.name, gh: f.goals.home, ga: f.goals.away }))
      fs.writeFileSync(HF, JSON.stringify(hist)); histErr = null
    } catch (e) { histErr = e.message; return }
    await sleep(7000)
  }
}
buildHistory(); setInterval(buildHistory, 3600000)

function formFor(team, before) {
  const raw = []
  for (const d of Object.keys(hist).filter((x) => x < before).sort().reverse()) {
    hist[d].forEach((f) => { if (f.h === team || f.a === team) raw.push({ ...f, date: d }) })
    if (raw.length >= 5) break
  }
  const top = raw.slice(0, 5)
  const list = top.map((f) => {
    const home = f.h === team, gf = home ? f.gh : f.ga, ga = home ? f.ga : f.gh
    return { res: gf > ga ? 'W' : gf < ga ? 'L' : 'D', opp: home ? f.an : f.hn, score: `${f.gh}:${f.ga}`, home, gf, ga, date: f.date }
  })
  return { raw: top, list }
}
const fromForm = (l) => (l.length >= 3 ? { gf: l.reduce((a, x) => a + x.gf, 0) / l.length, ga: l.reduce((a, x) => a + x.ga, 0) / l.length } : null)

// ---------- predikcija iz pravih podataka ----------
const FACT = [1, 1, 2, 6, 24, 120, 720, 5040, 40320]
const pois = (l, k) => Math.exp(-l) * l ** k / FACT[k]
const countGoals = (ms, T) => {
  const c = {}
  ms.forEach((m) => (m.events || []).filter((e) => e.type === 'Goal' && e.team.id === T && !['Missed Penalty', 'Own Goal'].includes(e.detail)).forEach((e) => { c[e.player.name] = (c[e.player.name] || 0) + 1 }))
  return c
}
function scorersFor(side, lu, counts, lam) {
  if (!lu) return []
  const W = { F: 1, M: 0.35, D: 0.1, G: 0 }
  const w = lu.players.map((p) => (W[p.pos] ?? 0.2) + 1.5 * (counts[p.name] || 0))
  const S = w.reduce((a, b) => a + b, 0) || 1
  return lu.players.map((p, i) => ({ name: p.name, team: side, goals: counts[p.name] || 0, chance: Math.round((1 - Math.exp(-lam * w[i] / S)) * 100) }))
}
function predict(c) {
  const ap = c.apiPrediction?.percent
  const api = ap && num(ap.home) != null ? { home: num(ap.home), draw: num(ap.draw), away: num(ap.away) } : null
  const a = fromForm(c.form.home), b = fromForm(c.form.away)
  let L = null, basis = null
  if (a && b) { L = [(a.gf + b.ga) / 2, (b.gf + a.ga) / 2]; basis = 'forma' }
  else if (api) { const t = (api.home - api.away) / 100; L = [1.35 + 0.6 * t, 1.35 - 0.6 * t]; basis = 'api' }
  if (!L) return null
  L = L.map((x) => Math.max(0.2, x))
  let best = [0, 0, -1], ph = 0, pd = 0, pa = 0
  for (let i = 0; i < 9; i++) for (let j = 0; j < 9; j++) {
    const p = pois(L[0], i) * pois(L[1], j)
    if (p > best[2]) best = [i, j, p]
    if (i > j) ph += p; else if (i < j) pa += p; else pd += p
  }
  const t = ph + pd + pa
  let probs = { home: (ph / t) * 100, draw: (pd / t) * 100, away: (pa / t) * 100 }
  if (api) probs = { home: (probs.home + api.home) / 2, draw: (probs.draw + api.draw) / 2, away: (probs.away + api.away) / 2 }
  const home = Math.round(probs.home), away = Math.round(probs.away)
  const scorers = [...scorersFor('home', c.lineups.home, c.counts.home, L[0]), ...scorersFor('away', c.lineups.away, c.counts.away, L[1])]
    .filter((s) => s.chance > 0).sort((x, y) => y.chance - x.chance).slice(0, 6)
  return { score: { home: best[0], away: best[1] }, probs: { home, away, draw: 100 - home - away }, xg: L.map((x) => Math.round(x * 10) / 10), basis, scorers }
}
function predLineup(lu, outSet) {
  if (!lu) return null
  const subs = [...lu.subs]
  const players = lu.players.map((p) => {
    if (!outSet.has(key(p.name))) return p
    const i = subs.findIndex((s) => s.pos === p.pos && !outSet.has(key(s.name)))
    return i >= 0 ? subs.splice(i, 1)[0] : null
  }).filter(Boolean)
  return { formation: lu.formation, players, subs }
}

async function context(id) {
  return memo('ctx' + id, 120000, async () => {
    const [fx] = await fb(`/fixtures?id=${id}`, 60000)
    if (!fx) throw new Error('Utakmica nije pronađena')
    const H = fx.teams.home.id, A = fx.teams.away.id, day = fx.fixture.date.slice(0, 10)
    const fh = formFor(H, day), fa = formFor(A, day)
    const [h2h, inj, pred] = await Promise.all([
      safe(fb(`/fixtures/headtohead?h2h=${H}-${A}`, 86400000)),
      safe(fb(`/injuries?fixture=${id}`, 600000)),
      safe(fb(`/predictions?fixture=${id}`, 3600000)),
    ])
    const done = (h2h || []).filter((f) => FIN.includes(f.fixture.status.short)).sort(desc)
    const recent = async (f) => (await Promise.all(f.raw.slice(0, 2).map((x) => safe(fb(`/fixtures?id=${x.id}`, 86400000))))).map((r) => r?.[0]).filter(Boolean)
    let [rh, ra] = await Promise.all([recent(fh), recent(fa)])
    let src = 'forma'
    if (!rh.length && !ra.length && done[0]) {
      const r = await safe(fb(`/fixtures?id=${done[0].fixture.id}`, 86400000))
      if (r?.[0]) { rh = ra = [r[0]]; src = 'međusobni meč' }
    }
    // povrede + datum povratka
    const injRaw = inj ?? []
    const ids = [...new Set(injRaw.map((i) => i.player.id))].slice(0, 20)
    const sid = ids.length ? await safe(fb(`/sidelined?players=${ids.join('-')}`, 86400000)) : null
    const today = new Date().toLocaleDateString('sv-SE')
    const back = (pid) => {
      const s = sid?.find((x) => x.id === pid)?.sidelined?.slice().sort((x, y) => new Date(y.start) - new Date(x.start))[0]
      return s?.end && s.end >= today ? s.end : null
    }
    const seen = new Set()
    const injuries = injRaw.filter((i) => !seen.has(i.player.id) && seen.add(i.player.id)).map((i) => ({ team: i.team.name, player: i.player.name, type: i.player.type, reason: i.player.reason, back: back(i.player.id) }))
    const out = (name) => new Set(injuries.filter((i) => i.team === name && i.type === 'Missing Fixture').map((i) => key(i.player)))

    const actual = { home: normLU(pick(fx.lineups, H)), away: normLU(pick(fx.lineups, A)) }
    const isActual = !!(actual.home && actual.away)
    const c = {
      fixture: slim(fx),
      form: { home: fh.list, away: fa.list },
      warnings: histErr ? ['Besplatan plan ne dozvoljava istoriju mečeva: ' + histErr] : fh.list.length < 5 || fa.list.length < 5 ? [`Istorija mečeva se još gradi u pozadini (${Object.keys(hist).length}/35 dana). Osveži za nekoliko minuta.`] : [],
      h2h: done.slice(0, 5).map((f) => ({ date: f.fixture.date.slice(0, 10), home: f.teams.home.name, away: f.teams.away.name, score: `${f.goals.home}:${f.goals.away}` })),
      injuries,
      apiPrediction: pred?.[0]?.predictions ? { percent: pred[0].predictions.percent } : null,
      lineupStatus: isActual ? 'actual' : 'predicted',
      lineupSource: isActual ? 'objavljen' : src,
      counts: { home: countGoals(rh, H), away: countGoals(ra, A) },
    }
    c.lineups = isActual ? actual : { home: predLineup(normLU(pick(rh[0]?.lineups, H)), out(fx.teams.home.name)), away: predLineup(normLU(pick(ra[0]?.lineups, A)), out(fx.teams.away.name)) }
    c.prediction = predict(c)
    return c
  })
}

// ---------- uživo / završene ----------
const SL = { 'Ball Possession': 'Posed lopte', expected_goals: 'Očekivani golovi (xG)', 'Total Shots': 'Šutevi', 'Shots on Goal': 'Šutevi u okvir', 'Corner Kicks': 'Korneri', Fouls: 'Prekršaji', Offsides: 'Ofsajdi', 'Yellow Cards': 'Žuti kartoni', 'Red Cards': 'Crveni kartoni', 'Goalkeeper Saves': 'Odbrane golmana', 'Passes %': 'Preciznost dodavanja' }

app.get('/api/match/:id/live', async (req, res) => {
  try {
    const id = req.params.id
    const [fx] = await fb(`/fixtures?id=${id}`, LIVE_TTL)
    if (!fx) throw new Error('Utakmica nije pronađena')
    const H = fx.teams.home.id, A = fx.teams.away.id
    const ev = fx.events ?? (await safe(fb(`/fixtures/events?fixture=${id}`, LIVE_TTL))) ?? []
    const st = fx.statistics?.length ? fx.statistics : (await safe(fb(`/fixtures/statistics?fixture=${id}`, LIVE_TTL))) ?? []
    const stH = pick(st, H)?.statistics || [], stA = pick(st, A)?.statistics || []
    const val = (arr, t) => arr.find((x) => x.type === t)?.value ?? 0
    const stats = Object.keys(SL).filter((t) => stH.some((x) => x.type === t) || stA.some((x) => x.type === t)).map((t) => {
      let h = val(stH, t), a = val(stA, t)
      if (t === 'Ball Possession' && num(h) != null && num(a) != null && num(h) + num(a) > 0) {
        const hp = Math.round((num(h) / (num(h) + num(a))) * 100)
        h = hp + '%'; a = 100 - hp + '%'
      }
      return { label: SL[t], home: h, away: a, h: num(h) || 0, a: num(a) || 0 }
    })
    const events = ev.filter((e) => ['Goal', 'Card', 'subst'].includes(e.type)).map((e) => ({
      t: e.time.elapsed, min: e.time.elapsed + (e.time.extra ? `+${e.time.extra}` : ''), side: e.team.id === H ? 'home' : 'away',
      type: e.type, detail: e.detail, comment: e.comment, player: e.player?.name, assist: e.assist?.name,
    }))
    const marks = {}
    const add = (n, k) => { if (n) (marks[n] = marks[n] || []).push(k) }
    events.forEach((e) => {
      if (e.type === 'Goal' && e.detail !== 'Missed Penalty') add(e.player, e.detail === 'Own Goal' ? 'og' : 'goal')
      else if (e.type === 'Card') add(e.player, e.detail?.includes('Red') ? 'red' : 'yellow')
      else if (e.type === 'subst') { add(e.player, 'out'); add(e.assist, 'in') }
    })
    const withMarks = (lu) => lu && { ...lu, players: lu.players.map((p) => ({ ...p, marks: marks[p.name] || [] })), subs: lu.subs.map((p) => ({ ...p, marks: marks[p.name] || [] })) }
    res.json({ fixture: slim(fx), events, stats, lineups: { home: withMarks(normLU(pick(fx.lineups, H))), away: withMarks(normLU(pick(fx.lineups, A))) }, lineupStatus: 'actual' })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

app.get('/api/fixtures', async (req, res) => {
  try { res.json((await fb(`/fixtures?date=${req.query.date}&timezone=Europe/Belgrade`, 300000)).map(slim)) }
  catch (e) { res.status(500).json({ error: e.message }) }
})
app.get('/api/match/:id', async (req, res) => {
  try { res.json(await context(req.params.id)) }
  catch (e) { res.status(500).json({ error: e.message }) }
})

app.listen(3001, () => console.log('Backend radi na http://localhost:3001'))
console.log('Football ključ:', process.env.FOOTBALL_API_KEY ? 'učitan' : 'NIJE učitan')